// File: /src/pages/SummarizePage.tsx
import React from 'react';

const SummarizePage: React.FC = () => {
  return (
    <div>
      <h1>Summarize Text</h1>
    </div>
  );
};

export default SummarizePage;