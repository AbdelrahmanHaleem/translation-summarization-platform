// File: /src/pages/HomePage.tsx
import React from 'react';

const HomePage: React.FC = () => {
  return (
    <div>
      <h1>Welcome to the Translation and Summarization Platform</h1>
    </div>
  );
};

export default HomePage;