// src/components/supertokensProvider.js
import React from 'react';
import SuperTokens from "supertokens-auth-react";
import EmailPassword from "supertokens-auth-react/recipe/emailpassword";
import Session from "supertokens-auth-react/recipe/session";

SuperTokens.init({
    appInfo: {
        appName: "MyApp",
        apiDomain: "http://localhost:3001",
        websiteDomain: "http://localhost:3000",
    },
    recipeList: [
        EmailPassword.init(),
        Session.init()
    ],
});

export const SuperTokensProvider = ({ children }) => {
    return (
        <SuperTokens.SuperTokensReact>
            {children}
        </SuperTokens.SuperTokensReact>
    );
};
