import { useState } from "react";
import { signUp } from "supertokens-web-js/recipe/emailpassword";

function Signup() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleSignup = async () => {
        await signUpClicked(email, password);
    };

    return (
        <div>
            <h2>Signup</h2>
            <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email"
            />
            <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password"
            />
            <button onClick={handleSignup}>Signup</button>
        </div>
    );
}

async function signUpClicked(email, password) {
    try {
        let response = await signUp({
            formFields: [
                { id: "email", value: email },
                { id: "password", value: password }
            ]
        });

        if (response.status === "FIELD_ERROR") {
            response.formFields.forEach(formField => {
                if (formField.id === "email") {
                    window.alert(formField.error);
                } else if (formField.id === "password") {
                    window.alert(formField.error);
                }
            });
        } else if (response.status === "SIGN_UP_NOT_ALLOWED") {
            window.alert(response.reason);
        } else {
            window.location.href = "/homepage";
        }
    } catch (err) {
        if (err.isSuperTokensGeneralError === true) {
            window.alert(err.message);
        } else {
            window.alert("Oops! Something went wrong.");
        }
    }
}

export default Signup;
