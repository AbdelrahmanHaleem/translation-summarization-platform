import { useState } from "react";
import { doesEmailExist } from "supertokens-web-js/recipe/emailpassword";

function EmailCheck() {
    const [email, setEmail] = useState('');

    const handleCheckEmail = async () => {
        await checkEmail(email);
    };

    return (
        <div>
            <h2>Check Email</h2>
            <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email"
            />
            <button onClick={handleCheckEmail}>Check Email</button>
        </div>
    );
}

async function checkEmail(email) {
    try {
        let response = await doesEmailExist({ email });

        if (response.doesExist) {
            window.alert("Email already exists. Please sign in instead");
        }
    } catch (err) {
        if (err.isSuperTokensGeneralError === true) {
            window.alert(err.message);
        } else {
            window.alert("Oops! Something went wrong.");
        }
    }
}

export default EmailCheck;
